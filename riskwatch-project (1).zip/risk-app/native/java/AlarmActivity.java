package ir.masoud.riskwatch;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.view.Gravity;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

/** صفحه تمام‌صفحه آلارم؛ روی صفحه قفل هم باز می‌شود */
public class AlarmActivity extends Activity {
    private String key = "";

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        if (Build.VERSION.SDK_INT >= 27) {
            setShowWhenLocked(true);
            setTurnScreenOn(true);
        } else {
            getWindow().addFlags(WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED | WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON);
        }
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        handle(getIntent());
    }

    @Override protected void onNewIntent(Intent i) {
        super.onNewIntent(i);
        setIntent(i);
        handle(i);
    }

    /** نوار هشدار راه‌راه بالا و پایین صفحه */
    static class Hazard extends View {
        private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        Hazard(Context c) { super(c); }
        @Override protected void onDraw(Canvas cv) {
            int w = getWidth(), h = getHeight();
            p.setColor(0x66000000);
            float step = h * 1.1f;
            for (float x = -h; x < w + h; x += step * 2) {
                Path path = new Path();
                path.moveTo(x, h);
                path.lineTo(x + step, h);
                path.lineTo(x + step + h, 0);
                path.lineTo(x + h, 0);
                path.close();
                cv.drawPath(path, p);
            }
        }
    }

    /** علامت مثلث هشدار */
    static class Icon extends View {
        private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        Icon(Context c) { super(c); }
        @Override protected void onDraw(Canvas cv) {
            float s = Math.min(getWidth(), getHeight());
            float u = s / 64f;
            p.setColor(Color.WHITE);
            p.setStyle(Paint.Style.STROKE);
            p.setStrokeWidth(4f * u);
            p.setStrokeJoin(Paint.Join.ROUND);
            Path t = new Path();
            t.moveTo(32 * u, 6 * u);
            t.lineTo(61 * u, 56 * u);
            t.lineTo(3 * u, 56 * u);
            t.close();
            cv.drawPath(t, p);
            p.setStyle(Paint.Style.FILL);
            cv.drawRoundRect(29.5f * u, 23 * u, 34.5f * u, 42 * u, 2.5f * u, 2.5f * u, p);
            cv.drawCircle(32 * u, 48 * u, 3.2f * u, p);
        }
    }

    private Button styled(String text, int textSize, int bg, int fg, int heightPx) {
        Button x = new Button(this);
        x.setText(text);
        x.setTextSize(textSize);
        x.setAllCaps(false);
        GradientDrawable g = new GradientDrawable();
        g.setColor(bg);
        g.setCornerRadius(12);
        x.setBackground(g);
        x.setTextColor(fg);
        x.setMinHeight(heightPx);
        return x;
    }

    private void handle(Intent i) {
        key = i.getStringExtra("key");
        if (i.getBooleanExtra("falsepos", false)) {
            AlarmHelper.markFalse(this, key);
            finish();
            return;
        }
        if (i.getBooleanExtra("ack", false)) {
            AlarmHelper.ack(this, key);
            finish();
            return;
        }
        String level = i.getStringExtra("level");
        boolean full = "full".equals(level);
        DisplayMetrics dm = getResources().getDisplayMetrics();
        float d = dm.density;

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        GradientDrawable bg = new GradientDrawable();
        bg.setGradientType(GradientDrawable.RADIAL_GRADIENT);
        bg.setGradientCenter(0.5f, 0.38f);
        bg.setGradientRadius(dm.widthPixels * 1.25f);
        bg.setColors(full ? new int[]{0xFFE5001F, 0xFF8A0012, 0xFF2A0007} : new int[]{0xFFD98200, 0xFF7A4700, 0xFF241300});
        root.setBackground(bg);

        root.addView(new Hazard(this), new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, (int) (26 * d)));

        LinearLayout mid = new LinearLayout(this);
        mid.setOrientation(LinearLayout.VERTICAL);
        mid.setGravity(Gravity.CENTER);
        mid.setPadding((int) (22 * d), (int) (10 * d), (int) (22 * d), (int) (10 * d));
        root.addView(mid, new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f));

        LinearLayout.LayoutParams ip = new LinearLayout.LayoutParams((int) (92 * d), (int) (92 * d));
        ip.bottomMargin = (int) (8 * d);
        mid.addView(new Icon(this), ip);

        TextView t = new TextView(this);
        t.setText(i.getStringExtra("title"));
        t.setTextColor(Color.WHITE);
        t.setTextSize(36);
        t.setTypeface(t.getTypeface(), android.graphics.Typeface.BOLD);
        t.setGravity(Gravity.CENTER);
        t.setShadowLayer(24, 0, 0, 0x88FFFFFF);
        t.setPadding(0, 0, 0, (int) (12 * d));
        mid.addView(t);

        TextView bd = new TextView(this);
        bd.setText(i.getStringExtra("body"));
        bd.setTextColor(Color.WHITE);
        bd.setTextSize(17);
        bd.setLineSpacing(0, 1.3f);
        bd.setGravity(Gravity.CENTER);
        bd.setPadding(0, 0, 0, (int) (14 * d));
        mid.addView(bd);

        String src = i.getStringExtra("src");
        if (src != null && !src.trim().isEmpty()) {
            TextView s = new TextView(this);
            s.setText(src.trim());
            s.setTextColor(0xFFFFE0E0);
            s.setTextSize(13);
            GradientDrawable sb = new GradientDrawable();
            sb.setColor(0x59000000);
            sb.setStroke(2, 0x40FFFFFF);
            sb.setCornerRadius(8);
            s.setBackground(sb);
            s.setPadding((int) (12 * d), (int) (10 * d), (int) (12 * d), (int) (10 * d));
            LinearLayout.LayoutParams sp = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
            sp.bottomMargin = (int) (16 * d);
            mid.addView(s, sp);
        }

        Button ack = styled("دیدم، خاموش کن", 20, Color.WHITE, 0xFF111111, (int) (62 * d));
        ack.setTypeface(ack.getTypeface(), android.graphics.Typeface.BOLD);
        ack.setOnClickListener(new View.OnClickListener() { @Override public void onClick(View v) {
            AlarmHelper.ack(AlarmActivity.this, key);
            finish();
        } });
        LinearLayout.LayoutParams a1 = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        mid.addView(ack, a1);

        Button mute = styled("فقط صدا را قطع کن", 15, 0x33FFFFFF, Color.WHITE, (int) (48 * d));
        mute.setOnClickListener(new View.OnClickListener() { @Override public void onClick(View v) { AlarmPlayer.stop(); } });
        LinearLayout.LayoutParams a2 = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        a2.topMargin = (int) (10 * d);
        mid.addView(mute, a2);

        Button fp = styled("این آلارم اشتباه بود", 14, 0x22FFFFFF, 0xFFFFE0E0, (int) (44 * d));
        fp.setOnClickListener(new View.OnClickListener() { @Override public void onClick(View v) {
            AlarmHelper.markFalse(AlarmActivity.this, key);
            finish();
        } });
        LinearLayout.LayoutParams a3 = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        a3.topMargin = (int) (8 * d);
        mid.addView(fp, a3);

        root.addView(new Hazard(this), new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, (int) (26 * d)));
        setContentView(root);
    }
}
