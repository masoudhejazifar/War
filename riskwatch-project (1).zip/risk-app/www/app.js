(function () {
'use strict';
const E = window.Engine, D = window.DemoData, Core = window.Core;
const $ = id => document.getElementById(id);
const HOUR = 3600e3, MIN = 60e3;
const fa = n => String(n).replace(/\d/g, d => '۰۱۲۳۴۵۶۷۸۹'[d]);

const isNative = !!(window.Capacitor && window.Capacitor.isNativePlatform && window.Capacitor.isNativePlatform());
const RN = (window.Capacitor && window.Capacitor.Plugins && window.Capacitor.Plugins.RiskNative) || null;
const nativeMode = isNative && !!RN;

/* ---------- ذخیره‌سازی ---------- */
function load(k, def) { try { const v = localStorage.getItem(k); return v ? JSON.parse(v) : def; } catch (e) { return def; } }
function save(k, v) { try { localStorage.setItem(k, JSON.stringify(v)); } catch (e) {} }
const lsStore = { get: (k, d) => load('wr_' + k, d), set: (k, v) => save('wr_' + k, v) };

let settings = Object.assign({ demo: !nativeMode && !isNative, interval: 1, wake: true, weights: {}, sources: {} }, load('wr_settings', {}));
let scenario = 'calm';
let S = { result: null, verified: [], rejected: [], ready: { level: 'none' }, alert: { level: 'none' }, health: {}, flights: null, lastCheck: 0, nextCheck: 0, newestTs: 0 };
const useNativePoll = () => nativeMode && !settings.demo;

function pushSettings() {
  if (!nativeMode) return;
  try { RN.setSettings({ json: JSON.stringify({ interval: settings.interval, wake: settings.wake, weights: settings.weights, sources: settings.sources }) }); } catch (e) {}
}

/* ---------- شبکه (فقط مرورگر/دمو؛ در اندروید سرویس خودش می‌خواند) ---------- */
async function httpText(url, timeout) {
  const c = new AbortController(); const t = setTimeout(() => c.abort(), timeout || 12000);
  try { const r = await fetch(url, { signal: c.signal, cache: 'no-store' }); if (!r.ok) throw new Error('HTTP ' + r.status); return await r.text(); }
  finally { clearTimeout(t); }
}
const webCore = Core.create({
  http: httpText, store: lsStore,
  getSettings: () => settings,
  demoScenario: () => (settings.demo ? scenario : null),
  emit: st => { S = st; render(); },
  netState: () => (navigator.onLine === false ? 'none' : 'unknown'),
  alarm: (level, info) => {
    if (level === 'incident') { toast('رویداد نظامی محدود گزارش شد؛ این آلارم جنگ نیست. ' + (info.items && info.items[0] ? info.items[0].title : '')); return; }
    if (level === 'ready') { ensureCtx(); chime(false); toast('آماده‌باش خانواده: ' + (info.why || '')); return; }
    activeAlarm = { level, key: info.key }; showWebAlarm(level, info, false);
  },
});

/* ---------- صدای آلارم (نرم؛ فقط برای مرورگر و دمو) ---------- */
let actx = null, sirenTimer = null, vibTimer = null, wake = null, activeAlarm = null;
function ensureCtx() {
  try { if (!actx) actx = new (window.AudioContext || window.webkitAudioContext)(); if (actx.state === 'suspended') actx.resume(); } catch (e) {}
  $('soundState').textContent = nativeMode ? '' : (actx && actx.state === 'running' ? 'صدا: فعال' : 'صدا: با اولین لمس فعال می‌شود');
}
function bell(freq, t0, dur, vol) {
  const o = actx.createOscillator(), g = actx.createGain();
  o.type = 'sine'; o.frequency.value = freq;
  g.gain.setValueAtTime(0.0001, t0); g.gain.exponentialRampToValueAtTime(vol, t0 + 0.03); g.gain.exponentialRampToValueAtTime(0.0001, t0 + dur);
  o.connect(g); g.connect(actx.destination); o.start(t0); o.stop(t0 + dur + 0.05);
}
function chime(full) {
  if (!actx) return; const t = actx.currentTime;
  if (full) { bell(659, t, 1.3, 0.22); bell(523, t + 0.6, 1.6, 0.22); } else { bell(587, t, 1.5, 0.18); }
}
function startSound(full) {
  stopSound(); ensureCtx(); chime(full);
  sirenTimer = setInterval(() => chime(full), full ? 3200 : 4800);
  try { if (navigator.vibrate) { const v = () => navigator.vibrate(full ? [350, 250, 350] : [250]); v(); vibTimer = setInterval(v, 3200); } } catch (e) {}
  try { if (navigator.wakeLock) navigator.wakeLock.request('screen').then(w => wake = w).catch(() => {}); } catch (e) {}
}
function stopSound() {
  clearInterval(sirenTimer); clearInterval(vibTimer); sirenTimer = vibTimer = null;
  try { navigator.vibrate && navigator.vibrate(0); } catch (e) {}
  try { if (wake) wake.release(); } catch (e) {} wake = null;
}
const CITY_FA = { Tehran:'تهران', Isfahan:'اصفهان', Tabriz:'تبریز', Shiraz:'شیراز', Mashhad:'مشهد', Bushehr:'بوشهر', Natanz:'نطنز', Fordow:'فردو', Parchin:'پارچین', BandarAbbas:'بندرعباس', Kermanshah:'کرمانشاه', Ahvaz:'اهواز', Karaj:'کرج', Qom:'قم', Arak:'اراک', Urmia:'ارومیه', Zahedan:'زاهدان', Hamedan:'همدان', Kharg:'خارک', Chabahar:'چابهار', Semnan:'سمنان', Iran:'ایران' };
const cityFa = c => CITY_FA[c] || c;
function esc(s) { return String(s == null ? '' : s).replace(/[&<>"]/g, c => ({ '&':'&amp;', '<':'&lt;', '>':'&gt;', '"':'&quot;' }[c])); }

function showWebAlarm(level, info, isTest) {
  const el = $('alarm');
  el.className = 'on ' + (level === 'ready' ? 'standby' : level);
  $('alarmTitle').textContent = level === 'full' ? (isTest ? 'آلارم آزمایشی: جنگ آغاز شده' : 'جنگ آغاز شد') : level === 'ready' ? 'آماده‌باش خانواده' : (isTest ? 'آماده‌باش آزمایشی' : 'آماده‌باش');
  const cities = (info.cities && info.cities.length) ? ' در ' + info.cities.map(cityFa).join('، ') : '';
  $('alarmBody').textContent = isTest ? 'این فقط یک آزمایش است.' :
    level === 'ready' ? 'نشانه‌های هشدار دیده شد (' + info.why + '). هنوز حمله‌ای تأیید نشده. مدارک، شارژ گوشی‌ها، آب و غذا و محل قرار خانواده را آماده کنید.' :
    level === 'full' ? 'حمله' + cities + ' از چند منبع مستقل تأیید شد. در آماده‌باش کامل باشید.' :
    'یک منبع معتبر خبر حمله' + cities + ' را با متن کامل داده است. در حال تأیید از منبع دوم.';
  $('alarmSrc').innerHTML = (info.items || []).map(i => '<div>• ' + esc(i.source) + ': ' + esc(i.title) + '</div>').join('') || '—';
  startSound(level === 'full');
}
function hideWebAlarm() { $('alarm').className = ''; stopSound(); activeAlarm = null; }
$('btnAck').onclick = () => {
  if (activeAlarm && activeAlarm.key) { const a = lsStore.get('acks', []); a.push(activeAlarm.key); lsStore.set('acks', a.slice(-50)); }
  hideWebAlarm(); render();
};
$('btnMute').onclick = () => stopSound();
$('btnTest').onclick = () => {
  if (nativeMode && !settings.demo) {
    try { RN.testAlarm({ level: 'full', delay: 10 }); toast('آلارم آزمایشی ۱۰ ثانیه دیگر می‌خورد. همین حالا صفحه را قفل کن تا روی صفحه قفل را هم ببینی.'); } catch (e) { toast('آلارم آزمایشی شروع نشد: ' + e); }
    return;
  }
  ensureCtx(); activeAlarm = { level: 'full', key: null };
  showWebAlarm('full', { cities: ['Tehran'], items: [{ source: 'آزمایش', title: 'این یک آلارم آزمایشی است' }] }, true);
};
let toastT = null;
function toast(msg) { const t = $('toast'); t.textContent = msg; t.className = 'toast on'; clearTimeout(toastT); toastT = setTimeout(() => t.className = 'toast', 9000); }

/* ---------- نمایش ---------- */
function ago(ts) {
  const sec = Math.round((Date.now() - ts) / 1000);
  if (sec < 5) return 'همین الان';
  if (sec < 60) return fa(sec) + ' ثانیه پیش';
  const m = Math.round(sec / 60); if (m < 60) return fa(m) + ' دقیقه پیش';
  const h = Math.round(m / 60); if (h < 48) return fa(h) + ' ساعت پیش'; return fa(Math.round(h / 24)) + ' روز پیش';
}
function inSec(ts) {
  const sec = Math.round((ts - Date.now()) / 1000);
  if (sec <= 0) return 'همین الان';
  if (sec < 60) return fa(sec) + ' ثانیه دیگر';
  return fa(Math.round(sec / 60)) + ' دقیقه دیگر';
}
const LVL_COLOR = { calm: '#19e68c', caution: '#ffb020', warning: '#ff7a1a', critical: '#ff2d3d' };
/* نیم‌دایره قطعه‌قطعه با درجه‌بندی (چپ سبز، راست قرمز) */
const STOPS = [[0, [25, 230, 140]], [0.28, [155, 226, 42]], [0.5, [255, 196, 0]], [0.72, [255, 122, 26]], [1, [255, 45, 61]]];
function colorAt(f) {
  for (let i = 1; i < STOPS.length; i++) if (f <= STOPS[i][0]) {
    const [f0, c0] = STOPS[i - 1], [f1, c1] = STOPS[i], t = (f - f0) / (f1 - f0);
    return 'rgb(' + c0.map((v, k) => Math.round(v + (c1[k] - v) * t)).join(',') + ')';
  }
  return 'rgb(255,45,61)';
}
function pol(cx, cy, r, th) { return [cx + r * Math.cos(th), cy - r * Math.sin(th)]; }
function gaugeSVG(id, big) {
  const W = big ? 340 : 120, H = big ? 190 : 72, cx = W / 2, cy = big ? 170 : 64;
  const r = big ? 118 : 46, t = big ? 22 : 11, N = big ? 50 : 22, gap = big ? 0.012 : 0.02;
  let s = '<svg viewBox="0 0 ' + W + ' ' + H + '" class="' + (big ? 'main-g' : '') + '" id="' + id + '" aria-hidden="true">';
  if (big) {
    s += '<defs><linearGradient id="' + id + '-sw" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#38d6ff" stop-opacity=".34"/><stop offset="1" stop-color="#38d6ff" stop-opacity="0"/></linearGradient></defs>';
    // پرتو رادار
    const a1 = Math.PI / 2 + 0.11, a2 = Math.PI / 2 - 0.11, ro = r + t / 2;
    const p1 = pol(cx, cy, ro, a1), p2 = pol(cx, cy, ro, a2);
    s += '<path class="sweep" style="--cx:' + cx + 'px;--cy:' + cy + 'px" d="M' + cx + ' ' + cy + ' L' + p1[0].toFixed(1) + ' ' + p1[1].toFixed(1) + ' A' + ro + ' ' + ro + ' 0 0 1 ' + p2[0].toFixed(1) + ' ' + p2[1].toFixed(1) + ' Z" fill="url(#' + id + '-sw)"/>';
    // حلقه‌های تزئینی و درجه‌ها
    const rOut = r + t / 2 + 8;
    const arc = (rad, w, col, dash) => { const a = pol(cx, cy, rad, Math.PI), b = pol(cx, cy, rad, 0); return '<path d="M' + a[0] + ' ' + a[1] + ' A' + rad + ' ' + rad + ' 0 0 1 ' + b[0] + ' ' + b[1] + '" fill="none" stroke="' + col + '" stroke-width="' + w + '"' + (dash ? ' stroke-dasharray="' + dash + '"' : '') + '/>'; };
    s += arc(rOut + 14, 1, 'rgba(120,170,220,.22)') + arc(r - t / 2 - 9, 1, 'rgba(120,170,220,.18)', '2 5');
    for (let k = 0; k <= 40; k++) {
      const th = Math.PI * (1 - k / 40), major = k % 10 === 0, mid = k % 5 === 0;
      const a = pol(cx, cy, rOut, th), b = pol(cx, cy, rOut + (major ? 11 : mid ? 7 : 4), th);
      s += '<line x1="' + a[0].toFixed(1) + '" y1="' + a[1].toFixed(1) + '" x2="' + b[0].toFixed(1) + '" y2="' + b[1].toFixed(1) + '" stroke="' + (major ? 'rgba(232,240,248,.85)' : 'rgba(120,170,220,.4)') + '" stroke-width="' + (major ? 1.6 : 1) + '"/>';
      if (major) { const q = pol(cx, cy, rOut + 25, th); s += '<text x="' + q[0].toFixed(1) + '" y="' + (q[1] + 3.5).toFixed(1) + '" fill="#7f93a8" font-size="10" font-weight="600" text-anchor="middle">' + fa(k * 2.5) + '</text>'; }
    }
  }
  for (let i = 0; i < N; i++) {
    const f = (i + 0.5) / N, th0 = Math.PI * (1 - i / N) - gap, th1 = Math.PI * (1 - (i + 1) / N) + gap;
    const p = pol(cx, cy, r, th0), q = pol(cx, cy, r, th1);
    s += '<path class="seg" data-f="' + (f * 100).toFixed(1) + '" style="color:' + colorAt(f) + ';transition-delay:' + (i * (big ? 9 : 14)) + 'ms" d="M' + p[0].toFixed(1) + ' ' + p[1].toFixed(1) + ' A' + r + ' ' + r + ' 0 0 1 ' + q[0].toFixed(1) + ' ' + q[1].toFixed(1) + '" fill="none" stroke="currentColor" stroke-width="' + t + '"/>';
  }
  const nl = r - t / 2 - (big ? 8 : 4), nw = big ? 3.4 : 2.2;
  s += '<g class="needle" style="transform-origin:' + cx + 'px ' + cy + 'px;transform:rotate(-90deg);filter:drop-shadow(0 0 ' + (big ? 5 : 3) + 'px rgba(255,255,255,.85))">' +
    '<path d="M' + (cx - nw) + ' ' + cy + ' L' + cx + ' ' + (cy - nl) + ' L' + (cx + nw) + ' ' + cy + ' L' + cx + ' ' + (cy + (big ? 14 : 8)) + ' Z" fill="#fff"/></g>' +
    '<circle cx="' + cx + '" cy="' + cy + '" r="' + (big ? 13 : 7) + '" fill="#071019" stroke="rgba(255,255,255,.9)" stroke-width="' + (big ? 2 : 1.4) + '"/>' +
    '<circle cx="' + cx + '" cy="' + cy + '" r="' + (big ? 4 : 2.2) + '" fill="#fff"/></svg>';
  return s;
}
function setGauge(id, score) {
  const el = $(id); if (!el) return;
  el.classList.toggle('g-off', score == null);
  el.querySelector('.needle').style.transform = 'rotate(' + ((score == null ? 0 : score) * 1.8 - 90) + 'deg)';
  el.querySelectorAll('.seg').forEach(sg => sg.classList.toggle('on', score != null && +sg.dataset.f <= score));
}
const MINIS = [
  { id: 'news', label: 'اخبار و دیپلماسی', from: ['news'] },
  { id: 'air', label: 'آسمان و پرواز', from: ['airspace', 'flights'] },
  { id: 'mil', label: 'نظامی و پدافند غیرعامل', from: ['military', 'civil'] },
  { id: 'emb', label: 'سفارتخانه‌ها', from: ['embassy'] },
  { id: 'mkt', label: 'بازارها و پیش‌بینی', from: ['markets', 'crowd'] },
  { id: 'net', label: 'اینترنت', from: ['internet'] },
];
function buildGauges() {
  $('mainGauge').innerHTML = '<div class="gwrap">' + gaugeSVG('gMain', true) + '</div>';
  $('minis').innerHTML = MINIS.map(m => '<div class="mini-g">' + gaugeSVG('g_' + m.id, false) +
    '<div class="n" id="n_' + m.id + '">—</div><div class="l">' + m.label + '</div></div>').join('');
}

function tickTimes() {
  if (!S.lastCheck) { $('updated').textContent = nativeMode && !settings.demo ? 'سرویس در حال شروع است…' : 'هنوز بررسی نشده'; return; }
  let t = 'آخرین بررسی: ' + ago(S.lastCheck);
  if (S.nextCheck) t += ' • بعدی: ' + inSec(S.nextCheck);
  $('updated').textContent = t;
  $('newest').textContent = S.newestTs ? 'تازه‌ترین خبر دریافتی: ' + ago(S.newestTs) : '';
  const stale = !S.demo && Date.now() - S.lastCheck > 5 * MIN;
  $('staleBox').className = 'blind' + (stale ? ' on' : '');
}
setInterval(tickTimes, 1000);

/* نمودار روند ۷۲ ساعته با نوارهای سطح */
function trendSVG(pts) {
  const W = 340, H = 96, pad = 4;
  if (!pts || pts.length < 2) return '<div class="empty">هنوز داده کافی برای نمودار نیست. بعد از چند ساعت پر می‌شود.</div>';
  const t0 = Date.now() - 72 * HOUR, t1 = Date.now();
  const X = t => pad + (Math.max(t0, t) - t0) / (t1 - t0) * (W - 2 * pad);
  const Y = s => H - pad - (s / 100) * (H - 2 * pad);
  const band = (a, b, col) => '<rect x="0" y="' + Y(b) + '" width="' + W + '" height="' + (Y(a) - Y(b)) + '" fill="' + col + '" opacity=".13"/>';
  const line = pts.map((p, i) => (i ? 'L' : 'M') + X(p.t).toFixed(1) + ' ' + Y(p.s).toFixed(1)).join(' ');
  const last = pts[pts.length - 1];
  return '<svg class="trendsvg" viewBox="0 0 ' + W + ' ' + H + '" aria-label="نمودار روند ۷۲ ساعته">' +
    band(0, 25, '#00c853') + band(25, 50, '#ffc400') + band(50, 75, '#ff7a00') + band(75, 100, '#ff2b2b') +
    '<defs><linearGradient id="tg" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#38d6ff" stop-opacity=".35"/><stop offset="1" stop-color="#38d6ff" stop-opacity="0"/></linearGradient></defs>' +
    '<path d="' + line + ' L' + X(last.t).toFixed(1) + ' ' + H + ' L' + X(pts[0].t).toFixed(1) + ' ' + H + ' Z" fill="url(#tg)"/>' +
    [1, 2, 3].map(k => '<line x1="' + (k * W / 4) + '" y1="0" x2="' + (k * W / 4) + '" y2="' + H + '" stroke="rgba(120,170,220,.12)" stroke-dasharray="2 4"/>').join('') +
    '<path d="' + line + '" fill="none" stroke="#e8f6ff" stroke-width="2" stroke-linejoin="round" style="filter:drop-shadow(0 0 4px #38d6ff)"/>' +
    '<circle cx="' + X(last.t).toFixed(1) + '" cy="' + Y(last.s).toFixed(1) + '" r="3.5" fill="#fff"/></svg>' +
    '<div class="ends" style="margin-top:2px"><span style="color:#93a0b3">۷۲ ساعت پیش</span><span style="color:#93a0b3">اکنون</span></div>';
}
function sparkSVG(vals) {
  if (!vals || vals.length < 3) return '';
  const W = 90, H = 20, mx = 100;
  const d = vals.map((v, i) => (i ? 'L' : 'M') + (i / (vals.length - 1) * W).toFixed(1) + ' ' + (H - 2 - (v / mx) * (H - 4)).toFixed(1)).join(' ');
  const l = vals[vals.length - 1];
  return '<svg class="spark" width="' + W + '" height="' + H + '" viewBox="0 0 ' + W + ' ' + H + '"><path d="' + d + '" fill="none" stroke="' + (l > 75 ? '#ff2b2b' : l > 50 ? '#ff7a00' : l > 25 ? '#ffc400' : '#00c853') + '" stroke-width="1.6"/></svg>';
}

/* ردیف خبر: تیتر خبر اصلی است، دلیل اهمیت زیرش؛ لمس ردیف، متن کامل خبر را باز می‌کند */
function newsRow(badge, headline, source, ts, why, url, extra) {
  const ok = url && /^https?:\/\//i.test(url);
  return '<div class="item' + (ok ? ' link' : '') + '"' + (ok ? ' data-url="' + esc(url) + '" role="link"' : '') + '>' + badge +
    '<div style="flex:1;min-width:0"><b>' + esc(headline) + '</b><span class="t">' + esc(source) + ' • ' + ago(ts) + (extra ? ' • ' + esc(extra) : '') + '</span>' +
    (why ? '<span class="why">' + why + '</span>' : '') + '</div>' + (ok ? '<span class="go" aria-hidden="true">‹ متن کامل</span>' : '') + '</div>';
}
function openExternal(url) {
  if (!/^https?:\/\//i.test(url)) return;
  try { if (nativeMode) RN.openUrl({ url }); else window.open(url, '_blank'); } catch (e) {}
}
document.addEventListener('click', e => { const el = e.target.closest && e.target.closest('[data-url]'); if (el) openExternal(el.getAttribute('data-url')); });

function render() {
  $('modeChip').className = 'chip ' + (settings.demo ? 'demo' : 'live');
  $('modeChip').textContent = settings.demo ? 'آزمایشی' : 'زنده';
  $('demoPanel').style.display = settings.demo ? '' : 'none';
  const r = S.result;
  if (r) {
    $('scoreNum').textContent = fa(r.final);
    $('lvlName').textContent = r.level.name;
    document.documentElement.style.setProperty('--lvl', LVL_COLOR[r.level.key]);
    setGauge('gMain', r.final);
    MINIS.forEach(m => {
      const vals = r.indicators.filter(i => m.from.includes(i.id) && i.available).map(i => i.risk);
      const v = vals.length ? Math.max.apply(null, vals) : null;
      setGauge('g_' + m.id, v);
      $('n_' + m.id).textContent = v == null ? '—' : fa(Math.round(v));
      const card = $('g_' + m.id).closest('.mini-g'); if (card) card.style.setProperty('--mc', v == null ? '#4b5d70' : v > 75 ? '#ff2d3d' : v > 50 ? '#ff7a1a' : v > 25 ? '#ffb020' : '#19e68c');
    });
    const d = S.trendRef != null ? r.final - S.trendRef : 0;
    $('trend').textContent = S.trendRef == null ? '' : d >= 3 ? '↑ رو به بدتر شدن' : d <= -3 ? '↓ رو به بهتر شدن' : '→ ثابت';
    $('trend').style.color = d >= 3 ? '#ff8a8a' : d <= -3 ? '#7dffb0' : '';
  }
  tickTimes();
  const act = E.SOURCES.filter(x => (settings.sources || {})[x.id] !== false);
  const allBad = !settings.demo && S.lastCheck && act.length && act.every(x => S.health[x.id] && S.health[x.id].state === 'bad');
  const blind = allBad || (!settings.demo && S.blind);
  $('blind').className = 'blind' + (blind ? ' on' : '');
  $('blind').innerHTML = S.offline ? '<b>گوشی الان هیچ اتصال اینترنتی ندارد.</b> تا وصل شدن دوباره، رصد و آلارم‌ها متوقف است (قطع اینترنت گوشی، قطع اینترنت ملی حساب نمی‌شود).'
    : '<b>اپ الان نمی‌تواند خبر زنده بگیرد.</b> تا وقتی این پیام هست آلارم نمی‌دهد و به آن تکیه نکنید. پایین صفحه «تست اتصال» را بزنید.';
  const rb = $('readyBox');
  if (S.ready && S.ready.level === 'ready') {
    rb.className = 'ready on';
    rb.innerHTML = '<b>آماده‌باش خانواده:</b> ' + esc(S.ready.why) + '.<br>هنوز حمله‌ای تأیید نشده، اما وقت آماده شدن است: مدارک، شارژ گوشی، آب و غذا، پول نقد، باک پر، محل قرار.';
  } else rb.className = 'ready';
  const a = S.alert || { level: 'none' }, st = $('alarmState');
  st.className = 'alarmstate ' + (a.level === 'none' || a.level === 'incident' ? '' : a.level);
  $('alarmText').textContent = a.level === 'full' ? 'آلارم کامل: حمله از دو منبع مستقل تأیید شده.' :
    a.level === 'standby' ? 'آماده‌باش: یک منبع معتبر با متن کامل خبر حمله گسترده داده، منتظر منبع دوم.' :
    a.level === 'incident' ? 'یک رویداد نظامی محدود گزارش شده. در جنگ جاری پیش می‌آید و آلارم جنگ نیست.' : 'آلارم آماده است. خبر حمله‌ای تأیید نشده.';

  $('trendCard').innerHTML = trendSVG(S.trend72 || []);
  const eff = r ? r.effective : [];
  const key = eff.filter(e => (e.tier === 'A' || e.tier === 'B' || e.tier === 'C') && e.pts > 0)
    .sort((x, y) => (x.tier === y.tier ? y.ts - x.ts : x.tier < y.tier ? -1 : 1)).slice(0, 15);
  const vlist = (S.verified || []).map(v => newsRow('<span class="tier X">حمله</span>', v.title, v.source, v.ts, 'خبر حمله: ' + (v.scale === 'wide' ? 'گسترده' : 'محدود') + ' • ' + (v.textLevel === 'full' ? 'متن کامل خوانده شد' : 'فقط خلاصه خبر'), v.link)).join('');
  $('keynews').innerHTML = vlist + (key.length ? key.map(e =>
    newsRow('<span class="tier ' + e.tier + '">' + e.tier + '</span>', e.title, e.source, e.ts, 'چرا مهم است: ' + esc(e.label) + (e.hypo ? ' (تیتر شرطی، اثر کم)' : '') + (e.ir ? ' (منبع ایرانی، اثر نصف)' : ''), e.link)).join('')
    : (vlist ? '' : '<div class="empty">نشانه مهمی دیده نشده. این‌جا فقط خبرهایی می‌آیند که یکی از نشانه‌های پیش از حمله را دارند.</div>'));
  $('reasons').innerHTML = eff.length ? eff.slice(0, 25).map(e => {
    const p = Math.round(e.pts * 10) / 10;
    return newsRow('<span class="pts ' + (p > 0 ? 'pos' : 'neg') + '">' + (p > 0 ? '+' : '') + fa(p) + '</span>', e.title, e.source, e.ts, 'دلیل امتیاز: ' + esc(e.label), e.link);
  }).join('') : '<div class="empty">هنوز دلیلی ثبت نشده.</div>';
  $('rejected').innerHTML = (S.rejected || []).length ? S.rejected.map(x => newsRow('<span class="pts rej">رد</span>', x.title, x.source, x.ts, 'دلیل رد: ' + esc(x.reason), x.link)).join('') : '<div class="empty">خبری رد نشده. تیترهای شرطی و زرد اینجا با دلیل نمایش داده می‌شوند.</div>';

  $('inds').innerHTML = (r ? r.indicators : E.INDICATORS.map(i => ({ name: i.name, weight: i.weight, risk: null, available: false, note: '' })))
    .map(i => '<div class="ind ' + (i.available ? '' : 'off') + '"><div class="top"><span>' + esc(i.name) + '</span><em>' + (i.available ? fa(Math.round(i.risk)) + ' از ۱۰۰' : 'بدون نمره') + ' • وزن ' + fa(i.weight) + '</em></div>' +
      '<div class="note">' + esc(i.note || '') + '</div>' + (i.available ? sparkSVG((S.ispark || {})[i.id]) : '') +
      (i.available ? '<div class="mini"><i style="width:' + i.risk + '%;--bw:' + (100 / Math.max(i.risk, 1) * 100) + '%"></i></div>' : '') + '</div>').join('');

  // بازارها
  const mk = S.markets || {}, cr = S.crowd || {};
  let mh = '<div class="note" style="padding:10px 12px">' + esc(mk.note || 'هنوز اندازه‌گیری نشده') + (mk.risk != null ? ' • نمره ' + fa(Math.round(mk.risk)) : '') + '</div>';
  mh += (mk.items || []).map(i => i.err ? '<div class="src"><span>' + esc(i.name) + '</span><span class="bad">' + esc(i.err) + '</span></div>' :
    '<div class="src"><span>' + esc(i.name) + (i.stale ? ' <em class="idle">(بازار بسته)</em>' : '') + '</span><span class="' + (i.stale || i.ch24 == null ? 'idle' : E.marketContrib(i.key, i) > 0 ? 'bad' : 'idle') + '" style="direction:ltr;unicode-bidi:isolate">' + (i.ch24 == null ? '—' : (i.ch24 > 0 ? '+' : '') + (Math.round(i.ch24 * 10) / 10) + '% · 24h') + '</span></div>').join('');
  mh += '<div class="note" style="padding:10px 12px;border-top:1px solid var(--line)">بازار پیش‌بینی: ' + esc(cr.note || 'هنوز اندازه‌گیری نشده') + '</div>';
  mh += (cr.items || []).map(i => '<div class="src"><span style="direction:ltr;text-align:left;flex:1">' + esc(i.q) + '</span><span class="' + (i.p >= 0.5 ? 'bad' : 'idle') + '">' + fa(Math.round(i.p * 100)) + '٪</span></div>').join('');
  $('mkts').innerHTML = mh;

  $('srcs').innerHTML = settings.demo ? '<div class="empty">در حالت آزمایشی به منابع واقعی وصل نمی‌شویم.</div>' :
    E.SOURCES.map(s => { const h = (S.health || {})[s.id]; const off = (settings.sources || {})[s.id] === false;
      return '<div class="src"><span>' + esc(s.name) + '</span><span class="' + (off ? 'idle' : !h ? 'idle' : h.state === 'ok' ? 'ok' : 'bad') + '">' + (off ? 'خاموش' : !h ? 'بررسی نشده' : h.state === 'ok' ? 'سالم • ' + fa(h.count) + ' خبر • ' + ago(h.last) : 'ناموفق: ' + esc(h.err || '')) + '</span></div>'; }).join('');
}

/* ---------- حالت اندروید: خواندن وضعیت از سرویس ---------- */
async function pollNative() {
  try {
    const r = await RN.getState();
    if (r.state) { S = JSON.parse(r.state); render(); } else tickTimes();
    $('stopBar').className = 'stopbar' + (r.alarmActive ? ' on' : '');
    if (!r.running) RN.startService();
  } catch (e) {}
}
async function refresh(force) {
  if (useNativePoll()) {
    if (force) { try { RN.checkNow(); } catch (e) {} setTimeout(pollNative, 2500); }
    return pollNative();
  }
  return webCore.runCheck();
}
$('btnCheck').onclick = async () => {
  ensureCtx(); $('btnCheck').textContent = 'در حال بررسی…';
  await refresh(true); setTimeout(() => $('btnCheck').textContent = 'بررسی الان', 2500);
};
let loopT = null;
function loop() {
  clearTimeout(loopT);
  const ms = useNativePoll() ? 2000 : Math.max(1, +settings.interval || 1) * MIN;
  loopT = setTimeout(async () => { await refresh(false); loop(); }, ms);
}

/* ---------- درباره اپ و روش محاسبه ---------- */
function openAbout() {
  const rows = E.INDICATORS.map(i => '<tr><td>' + esc(i.name) + '</td><td>' + fa(settings.weights[i.id] != null ? settings.weights[i.id] : i.weight) + '</td></tr>').join('');
  $('aboutBody').innerHTML =
    '<h3>پایش خطر جنگ</h3><div class="made">ساخته‌شده توسط مسعود</div>' +
    '<p>ایده، نیازها، آزمایش و همه تصمیم‌های این اپ از مسعود است. کدنویسی با کمک دستیار هوش مصنوعی Claude (ساخت شرکت Anthropic) انجام شده است. نسخه ' + fa('0.9') + ' — آبان ' + fa('1405') + '.</p>' +
    '<h4>این اپ دقیقاً چه کار می‌کند؟</h4><ul>' +
    '<li>هر ۱ دقیقه تیترها و متن خبر رویترز، AP، BBC، الجزیره و خبرگزاری‌های ایرانی را می‌خواند و دنبال نشانه‌های پیش از حمله می‌گردد.</li>' +
    '<li>هر نشانه یک رده دارد: <b>A</b> (ساعت‌ها تا یک روز زودتر)، <b>B</b> (چند روز)، <b>C</b> (هفته‌ها). مثال: دستور خروج کارکنان سفارت، بسته شدن آسمان ایران، تخلیه کارشناسان روسیه.</li>' +
    '<li>ترافیک هوایی منطقه (OpenSky)، بازارهای مالی و نفت، بازار پیش‌بینی (Polymarket)، و لحن اظهارات رهبران را کنارش می‌گذارد.</li>' +
    '<li>همه را به یک نمره از ۰ تا ۱۰۰ روی نیم‌دایره (چپ سبز، راست قرمز) تبدیل می‌کند. نمره هموار است: بالا رفتن سریع (نیمه‌عمر ۳ ساعت)، پایین آمدن آهسته (۱۲ ساعت).</li>' +
    '<li>اگر چند نشانگر مستقل همزمان بالا باشند، نمره با ضریب ۱٫۰۸ تا ۱٫۲۵ بیشتر می‌شود.</li>' +
    '<li>با سرویس همیشه‌فعال روی گوشی، حتی با صفحه خاموش، آلارم می‌دهد. ویجت صفحه اصلی نمره را نشان می‌دهد.</li></ul>' +
    '<h4>آلارم‌ها</h4><ul>' +
    '<li><b>رویداد محدود:</b> اعلان بی‌صدا (در جنگ جاری پیش می‌آید).</li>' +
    '<li><b>آماده‌باش خانواده:</b> فقط با شواهد تازه، یک زنگ نرم، حداکثر هر ۶ ساعت.</li>' +
    '<li><b>آماده‌باش حمله / آلارم کامل:</b> حمله گسترده؛ یک منبع با متن کامل یا دو منبع مستقل. صدای نرم تکرارشونده و صفحه تمام‌صفحه.</li>' +
    '<li>انفجار گاز، آتش‌سوزی، آتش‌بازی، رزمایش، تیتر شرطی («اگر…») و تعطیلی بخاطر آلودگی هوا رد می‌شوند.</li>' +
    '<li>اگر گوشی آفلاین باشد یا هیچ منبعی جواب ندهد، آلارم نمی‌دهد و روی صفحه اعلام می‌کند.</li></ul>' +
    '<h4>نشانگرها و وزن‌ها</h4><table><tr><th>نشانگر</th><th>وزن</th></tr>' + rows + '</table>' +
    '<p style="font-size:12px;color:#93a0b3">وزن‌ها بر قضاوت تحلیلی و بررسی چهار بحران (۲۰۲۴ تا ۲۰۲۶) است، نه مدل آماری اعتبارسنجی‌شده. در تنظیمات می‌توان تغییرشان داد.</p>' +
    '<h4>این اپ چه کارهایی را نمی‌کند</h4><ul>' +
    '<li>پیش‌بینی قطعی نمی‌کند؛ فقط تخمین است و <b>جایگزین هشدارهای رسمی و آژیر نیست</b>.</li>' +
    '<li>هیچ سیستمی بدون هشدار اشتباه نیست. بعضی نشانه‌ها (بورس، تلفن همراه، مدارس) بعد از شروع حمله دیده می‌شوند.</li>' +
    '<li>اگر اینترنت یا شبکه موبایل قطع شود، خبر تازه نمی‌گیرد.</li>' +
    '<li>هواپیماهایی که ترنسپوندر را خاموش می‌کنند دیده نمی‌شوند.</li></ul>' +
    '<h4>حریم خصوصی</h4><p>حساب کاربری و ثبت‌نام ندارد و هیچ اطلاعات شخصی جمع نمی‌کند. فقط درخواست خواندن خبر، پرواز و قیمت از اینترنت می‌فرستد. تنظیمات و گزارش‌ها فقط روی همین گوشی می‌مانند.</p>';
  $('dlgAbout').showModal();
}
$('btnAbout').onclick = openAbout;
$('btnAboutClose').onclick = () => $('dlgAbout').close();

/* ---------- دکمه قطع آلارم، ثبت اشتباه، بی‌صدا ---------- */
$('btnStop').onclick = async () => { try { await RN.stopAlarm(); } catch (e) {} $('stopBar').className = 'stopbar'; hideWebAlarm(); };
$('btnFalse').onclick = async () => { try { await RN.markFalse({}); } catch (e) {} $('stopBar').className = 'stopbar'; toast('ثبت شد. همین شواهد دیگر آلارم نمی‌سازند و برای بازنگری در گزارش می‌ماند.'); };
$('btnMute6').onclick = () => { settings.mutedUntil = Date.now() + 6 * HOUR; save('wr_settings', settings); pushSettings(); toast('آماده‌باش‌ها و رویدادهای محدود ۶ ساعت بی‌صدا شد. آلارم کامل همیشه صدا می‌دهد.'); };

/* ---------- گزارش آلارم‌ها و تست دقت ---------- */
function reportText() {
  const rep = { نسخه: '0.9', زمان: new Date().toISOString(), نمره: S.result && S.result.final, آماده‌باش: S.ready && S.ready.level, آلارم: S.alert && S.alert.level,
    کور: !!S.blind, آفلاین: !!S.offline, گزارش_آلارم‌ها: S.log || [], خطای_منابع: Object.fromEntries(Object.entries(S.health || {}).filter(([k, v]) => v.state === 'bad').map(([k, v]) => [k, v.err])),
    ردشده‌ها: (S.rejected || []).slice(0, 6).map(r => r.title + ' ← ' + r.reason) };
  return JSON.stringify(rep, null, 1);
}
function openLog() {
  const ST = window.SelfTest ? window.SelfTest.run(E) : null;
  const lg = (S.log || []).slice().reverse();
  const act = { 'suppressed:blind': 'متوقف شد (داده زنده نبود)', 'suppressed:cooldown': 'متوقف شد (فاصله مجاز)', 'suppressed:false-positive': 'متوقف شد (قبلاً اشتباه ثبت شده)' };
  const L = { full: 'آلارم کامل', standby: 'آماده‌باش حمله', ready: 'آماده‌باش خانواده', incident: 'رویداد محدود' };
  $('logOut').innerHTML = '<div class="note" style="padding:10px 12px"><b>تست دقت تشخیص:</b> ' + (ST ? fa(ST.passed) + ' از ' + fa(ST.total) + ' مورد درست' + (ST.failures.length ? '<br>' + ST.failures.map(esc).join('<br>') : ' ✓') : 'در دسترس نیست') + '</div>' +
    (lg.length ? lg.map(x => '<div class="item"><span class="pts rej">' + esc(L[x.level] || x.level) + '</span><div><b>' + esc(String(x.action).startsWith('fired') ? 'اعلام شد' : (act[x.action] || x.action)) + ' • ' + ago(x.t) + '</b><span class="t">' + esc(x.why || (x.items || []).join(' | ')) + '</span></div></div>').join('') : '<div class="empty">هنوز آلارمی ثبت نشده.</div>');
  $('logText').value = reportText();
  $('dlgLog').showModal();
}
$('btnLog').onclick = openLog;
$('btnLogClose').onclick = () => $('dlgLog').close();
$('btnLogCopy').onclick = async () => {
  const t = $('logText'); t.select();
  try { await navigator.clipboard.writeText(t.value); toast('گزارش کپی شد. آن را برای Claude بفرست.'); } catch (e) { try { document.execCommand('copy'); toast('گزارش کپی شد.'); } catch (x) { toast('کپی نشد؛ متن را دستی انتخاب و کپی کن.'); } }
};

/* ---------- تنظیمات لازم برای باز ماندن (اندروید) ---------- */
let permShown = false;
const BRAND_HINT = {
  xiaomi: 'شیائومی: تنظیمات ← برنامه‌ها ← مدیریت برنامه‌ها ← RiskWatch ← «شروع خودکار» را روشن و «صرفه‌جویی باتری» را روی «بدون محدودیت» بگذارید.',
  redmi: 'شیائومی: تنظیمات ← برنامه‌ها ← مدیریت برنامه‌ها ← RiskWatch ← «شروع خودکار» را روشن و «صرفه‌جویی باتری» را روی «بدون محدودیت» بگذارید.',
  poco: 'شیائومی: تنظیمات ← برنامه‌ها ← مدیریت برنامه‌ها ← RiskWatch ← «شروع خودکار» را روشن و «صرفه‌جویی باتری» را روی «بدون محدودیت» بگذارید.',
  samsung: 'سامسونگ: تنظیمات ← باتری ← «محدودیت‌های استفاده در پس‌زمینه» ← RiskWatch را از «برنامه‌های خواب» خارج کنید و «هرگز خواب نرود» را روشن کنید.',
  huawei: 'هوآوی: تنظیمات ← باتری ← راه‌اندازی برنامه‌ها ← RiskWatch ← مدیریت دستی ← هر سه گزینه (راه‌اندازی خودکار، راه‌اندازی ثانویه، اجرا در پس‌زمینه) روشن.',
  honor: 'هوآوی/آنر: تنظیمات ← باتری ← راه‌اندازی برنامه‌ها ← RiskWatch ← مدیریت دستی ← هر سه گزینه روشن.',
  oppo: 'اوپو: تنظیمات ← باتری ← RiskWatch ← «اجازه فعالیت در پس‌زمینه» و «شروع خودکار» را روشن کنید.',
  realme: 'ریلمی: تنظیمات ← باتری ← RiskWatch ← «اجازه فعالیت در پس‌زمینه» و «شروع خودکار» را روشن کنید.',
  vivo: 'ویوو: تنظیمات ← باتری ← مصرف انرژی پس‌زمینه ← RiskWatch ← «اجازه اجرا در پس‌زمینه» را روشن کنید.',
};
async function checkPerms(openIfMissing) {
  if (!nativeMode) return;
  let st; try { st = await RN.getStatus(); } catch (e) { return; }
  const manual = load('wr_manual', {});
  const items = [
    { id: 'notifications', ok: st.notifications, title: 'اعلان‌ها', why: 'بدون آن آلارم و پیام آماده‌باش نمایش داده نمی‌شود.', btn: 'فعال کن' },
    { id: 'battery', ok: st.battery, title: 'اجرا بدون محدودیت باتری', why: 'بدون آن اندروید رصد را می‌بندد.', btn: 'فعال کن' },
    { id: 'fullscreen', ok: st.fullScreen, title: 'نمایش آلارم روی صفحه قفل', why: 'تا آلارم حتی با گوشی قفل‌شده تمام‌صفحه باز شود.', btn: 'فعال کن' },
    { id: 'autostart', ok: !!manual.autostart, manual: true, title: 'شروع خودکار و تنظیم باتری برند گوشی', why: BRAND_HINT[st.brand] || 'در تنظیمات گوشی برای این اپ «شروع خودکار / اجرا در پس‌زمینه» را روشن و صرفه‌جویی باتری را «بدون محدودیت» کنید.', btn: 'باز کردن تنظیمات اپ' },
    { id: 'recents', ok: !!manual.recents, manual: true, title: 'قفل کردن اپ در لیست اخیر', why: 'دکمه برنامه‌های اخیر را بزنید، روی کارت اپ نگه دارید یا آیکونش را بزنید و «قفل» را انتخاب کنید.', btn: '' },
  ];
  $('permList').innerHTML = items.map(i => '<div class="perm ' + (i.ok ? 'done' : '') + '"><div class="ph"><span class="pk">' + (i.ok ? '✓' : '!') + '</span><b>' + esc(i.title) + '</b></div><div class="note">' + esc(i.why) + '</div>' +
    (i.manual ? '<div class="prow">' + (i.btn ? '<button class="btn" data-open="app">' + i.btn + '</button>' : '') + '<label class="chk"><input type="checkbox" data-manual="' + i.id + '" ' + (i.ok ? 'checked' : '') + '> انجام دادم</label></div>'
              : (i.ok ? '' : '<div class="prow"><button class="btn primary" data-open="' + i.id + '">' + i.btn + '</button></div>')) + '</div>').join('') +
    '<div class="perm"><div class="ph"><span class="pk">i</span><b>ویجت صفحه اصلی</b></div><div class="note">صفحه اصلی گوشی را نگه دارید ← ویجت‌ها ← «پایش خطر» را بکشید روی صفحه.</div></div>';
  $('permList').querySelectorAll('[data-open]').forEach(b => b.onclick = () => { try { RN.openSetting({ name: b.dataset.open }); } catch (e) {} });
  $('permList').querySelectorAll('[data-manual]').forEach(c => c.onchange = () => { const m = load('wr_manual', {}); m[c.dataset.manual] = c.checked; save('wr_manual', m); checkPerms(false); });
  const missing = items.filter(i => !i.ok).length;
  $('permBanner').className = 'blind perm-banner' + (missing ? ' on' : '');
  $('permBanner').textContent = missing ? 'برای کار کردن آلارم، ' + fa(missing) + ' تنظیم باقی مانده است. اینجا را بزنید.' : '';
  if (missing && openIfMissing && !permShown) { permShown = true; if (!$('dlgPerm').open) $('dlgPerm').showModal(); }
}
$('permBanner').onclick = () => { checkPerms(false); $('dlgPerm').showModal(); };
$('btnPermClose').onclick = () => $('dlgPerm').close();
document.addEventListener('visibilitychange', () => { if (!document.hidden) { checkPerms(false); refresh(false); } });

/* ---------- تست اتصال ---------- */
async function testUrl(url) {
  if (nativeMode) { const r = await RN.httpGet({ url }); if (r.error) throw new Error(r.error); if (r.status >= 400) throw new Error('HTTP ' + r.status); return r.length; }
  return (await httpText(url, 10000)).length;
}
async function runDiag() {
  const out = $('diagOut');
  const tests = [
    ['OpenSky (پرواز)', 'https://opensky-network.org/api/states/all?lamin=35&lomin=51&lamax=36&lomax=52'],
    ['Cloudflare', 'https://www.cloudflare.com/cdn-cgi/trace'],
    ['آپارات (داخلی)', 'https://www.aparat.com/'],
    ['ایرنا RSS (داخلی)', 'https://www.irna.ir/rss'],
    ['BBC (از طریق گوگل)', E.SOURCES.find(s => s.id === 'bbcen').url],
    ['BBC فارسی (از طریق گوگل)', E.SOURCES.find(s => s.id === 'bbcfa').url],
    ['الجزیره RSS', 'https://www.aljazeera.com/xml/rss/all.xml'],
    ['بازار مالی (Yahoo)', E.marketUrl('BZ=F')],
    ['Polymarket', E.crowdUrl('US strikes Iran')],
  ];
  let html = '<div class="note">نسخه ۰٫۹ • اندروید: ' + (isNative ? 'بله' : 'خیر (مرورگر)') + ' • سرویس پس‌زمینه: ' + (nativeMode ? 'فعال' : 'ندارد') + '</div>';
  out.innerHTML = html;
  for (const [name, url] of tests) {
    out.innerHTML = html + '<div class="src"><span>' + name + '</span><span class="idle">در حال تست…</span></div>';
    let line;
    try { const n = await testUrl(url); line = '<span class="ok">موفق • ' + fa(n) + ' بایت</span>'; } catch (e) { line = '<span class="bad">' + esc(Core.shortErr(e)) + '</span>'; }
    html += '<div class="src"><span>' + name + '</span>' + line + '</div>';
  }
  out.innerHTML = html;
}
$('btnDiag').onclick = () => { $('dlgDiag').showModal(); runDiag(); };
$('btnDiagClose').onclick = () => $('dlgDiag').close();

/* ---------- دمو ---------- */
function buildDemo() {
  const g = $('demoGrid'); g.innerHTML = '';
  Object.keys(D.SCENARIOS).forEach(k => {
    const b = document.createElement('button'); b.textContent = D.SCENARIOS[k].label;
    if (k === scenario) b.className = 'on';
    b.onclick = () => { scenario = k; lsStore.set('acks', []); webCore.resetAlarmKey(); hideWebAlarm(); buildDemo(); webCore.runCheck(); };
    g.appendChild(b);
  });
}

/* ---------- تنظیمات ---------- */
function openSettings() {
  $('setDemo').checked = settings.demo; $('setInt').value = settings.interval; $('setWake').checked = settings.wake !== false;
  $('wakeRow').style.display = nativeMode ? '' : 'none';
  $('weights').innerHTML = E.INDICATORS.filter(i => i.available).map(i => {
    const w = settings.weights[i.id] != null ? settings.weights[i.id] : i.weight;
    return '<div class="field"><label><span>' + esc(i.name) + '</span><b id="wv_' + i.id + '">' + fa(w) + '</b></label><input type="range" min="0" max="40" value="' + w + '" data-w="' + i.id + '"></div>';
  }).join('');
  $('weights').querySelectorAll('input').forEach(r => r.oninput = () => $('wv_' + r.dataset.w).textContent = fa(r.value));
  $('srcToggles').innerHTML = E.SOURCES.map(s => '<div class="sw"><span>' + esc(s.name) + '</span><input type="checkbox" data-s="' + s.id + '" ' + (settings.sources[s.id] === false ? '' : 'checked') + '></div>').join('');
  $('dlg').showModal();
}
$('btnSettings').onclick = openSettings;
$('btnClose').onclick = () => $('dlg').close();
$('btnSave').onclick = () => {
  settings.demo = $('setDemo').checked; settings.interval = Math.max(1, +$('setInt').value || 1); settings.wake = $('setWake').checked;
  $('weights').querySelectorAll('input').forEach(r => settings.weights[r.dataset.w] = +r.value);
  $('srcToggles').querySelectorAll('input').forEach(c => settings.sources[c.dataset.s] = c.checked);
  save('wr_settings', settings); pushSettings(); $('dlg').close();
  S = { result: null, verified: [], rejected: [], ready: { level: 'none' }, alert: { level: 'none' }, health: {}, flights: null, lastCheck: 0, nextCheck: 0, newestTs: 0 };
  render(); refresh(true); loop();
};
$('btnReset').onclick = () => { settings = { demo: !nativeMode && !isNative, interval: 1, wake: true, weights: {}, sources: {} }; save('wr_settings', settings); pushSettings(); $('dlg').close(); refresh(true); loop(); };
document.addEventListener('pointerdown', ensureCtx);

function clock() { try { $('clock').textContent = new Date().toLocaleTimeString('en-GB', { timeZone: 'Asia/Tehran', hour12: false }) + '  IRST'; } catch (e) {} }
clock(); setInterval(clock, 1000);
buildGauges(); buildDemo(); render(); ensureCtx();
pushSettings();
if (nativeMode) { try { RN.startService(); } catch (e) {} checkPerms(true); }
refresh(false); loop();
})();
